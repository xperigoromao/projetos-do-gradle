package Checkers;
public class MainCheckers {
    public void playCheckers() {
		System.out.println("MODULE CHECKERS WAS INITIATED");
		System.out.println("LET'S PLAY CHECKERS");
    }
}
