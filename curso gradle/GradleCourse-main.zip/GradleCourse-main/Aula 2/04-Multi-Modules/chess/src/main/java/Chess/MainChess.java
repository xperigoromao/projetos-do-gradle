package Chess;
public class MainChess {
    public void playChess() {
		System.out.println("MODULE CHESS WAS INITIATED");
		System.out.println("LET'S PLAY CHESS");
    }
}
